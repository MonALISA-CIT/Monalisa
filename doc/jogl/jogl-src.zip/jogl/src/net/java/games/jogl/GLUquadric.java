package net.java.games.jogl;

/**
 * Wrapper for a GLU quadric object.
 */

public interface GLUquadric {
}
