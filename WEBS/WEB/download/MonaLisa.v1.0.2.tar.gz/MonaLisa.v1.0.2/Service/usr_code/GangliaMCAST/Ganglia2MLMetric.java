public class Ganglia2MLMetric {

    public String gMetric;
    public String mlMetric;
    public int xdrType;
    
    public Ganglia2MLMetric( String gMetric, String mlMetric, int xdrType ) {
        this.gMetric = gMetric;
        this.mlMetric = mlMetric;
        this.xdrType = xdrType;
    }
}
