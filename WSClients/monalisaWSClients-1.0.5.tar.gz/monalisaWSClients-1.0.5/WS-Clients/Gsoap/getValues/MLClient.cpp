
 #include "soapH.h" // obtain the generated stub 
 #include "MLWebServiceSoapBinding.nsmap" // obtain the namespace mapping table 
 
 int main(int argc, char** argv) 
 { 
 
    if (argc != 7) {
	printf ("Wrong number of parameters:\n");
	printf ("Call example: ./run_client  <farm_name>  <cluster_name>  <node_name>  <param_name>  <fromTime>  <toTime> \n");
	return 0;
    } else {
	char* farmName = argv[1];
	char* clusterName = argv[2];
	char* nodeName = argv[3];
	char* paramName = argv[4];
	long fromTime = atol(argv[5]);
	long toTime = atol(argv[6]);
	
	struct soap soap; // gSOAP runtime environment 
	float quote; 
    
	struct ns1__getValuesResponse resp2;
    
	soap_init(&soap); // initialize runtime environment (only once) 
	if (soap_call_ns1__getValues(&soap, NULL, NULL, (std::string)farmName, (std::string)clusterName, (std::string)nodeName, (std::string)paramName, (long long int)fromTime, (long long int)toTime, resp2) == SOAP_OK) {
   
    	    printf("number of results: %d\n",resp2._getValuesReturn->__size);
    	    for(int i=0;i<resp2._getValuesReturn->__size;i++) {
    		ns3__Result *results = resp2._getValuesReturn->__ptr[i];
    		time_t epochtime = static_cast<time_t> (results->time/1000);
		char tstr[24];
    		ctime_r(&epochtime,tstr); tstr[24]='\0';
    		printf("farm: %s\n |----cluster: %s\n      |----node: %s  (time: %lld ms = %s)\n",
                results->farmName->c_str(),results->clusterName->c_str(),results->nodeName->c_str(),
                results->time,tstr);
		ns2__Map* params = results->param;       
    		for(int j=0 ; j < params->item.size() ; j++) {
        	    printf("           |----%s\tValue: %s\n",(((xsd__string*)(params->item[j]->key))->__item).c_str(),(params->item[j]->value)->__item );
    		} // for
	    } // for	
        } else { // an error occurred 
	    soap_print_fault(&soap, stderr); // display the SOAP fault message on the stderr stream 
	} // if - else

	soap_destroy(&soap); // delete deserialized class instances (for C++ only) 
	soap_end(&soap); // remove deserialized data and clean up 
	soap_done(&soap); // detach the gSOAP environment 
    } // if - lese
    return 0; 
 }
