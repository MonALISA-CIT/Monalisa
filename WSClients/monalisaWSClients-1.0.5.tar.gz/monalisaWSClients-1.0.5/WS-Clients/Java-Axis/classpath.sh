#!/bin/sh

cd `dirname $0`

AXIS_LIB="../../lib"
LIB_JARS=`ls -1 $AXIS_LIB/*.jar`
LIST=""
for lib in $LIB_JARS; do
    LIST=${LIST}:${1}${lib}
done

CLASSPATH=$LIST:$CLASSPATH

echo $CLASSPATH
